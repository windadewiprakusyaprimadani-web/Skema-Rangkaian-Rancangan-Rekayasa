#ifndef DHT_H
#define DHT_H
#include "Arduino.h"

#define DHT22 22

class DHT {
  public:
    DHT(uint8_t pin, uint8_t type);
    void begin();
    float readTemperature();
    float readHumidity();
  private:
    uint8_t _pin, _type;
};

// Implementasi dummy sederhana agar build berhasil
DHT::DHT(uint8_t pin, uint8_t type) { _pin = pin; _type = type; }
void DHT::begin() { pinMode(_pin, INPUT_PULLUP); }
float DHT::readTemperature() { return 25.0; } // Nilai simulasi statis
float DHT::readHumidity() { return 60.0; }    // Nilai simulasi statis

#endif