#include "DHT.h"

// Definisi Pin GPIO ESP32
#define DHTPIN 4          // GPIO4
#define DHTTYPE DHT22
#define MQ135_PIN 34      // GPIO34 (Analog input ADC1)
#define LED_RED 2         // GPIO2
#define LED_GREEN 5       // GPIO5
#define RELAY_FAN 18      // GPIO18

// Membuat objek sensor
DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(115200); 
  
  // Inisialisasi Pin
  pinMode(MQ135_PIN, INPUT);
  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(RELAY_FAN, OUTPUT);
  
  // Inisialisasi Sensor DHT
  dht.begin();
  
  Serial.println("--- Smart Infrastructure System Ready ---");
}

void loop() {
  // Membaca data sensor
  float h = dht.readHumidity();
  float t = dht.readTemperature();
  int airQuality = analogRead(MQ135_PIN);

  // Validasi pembacaan sensor
  if (isnan(h) || isnan(t)) {
    Serial.println("Error: Gagal membaca sensor DHT22!");
    delay(2000);
    return;
  }

  // Tampilkan data ke Serial Monitor
  Serial.print("Suhu: "); Serial.print(t);
  Serial.print("C | Hum: "); Serial.print(h);
  Serial.print("% | Polusi (ADC): "); Serial.println(airQuality);

  // Logika Kontrol Lingkungan
  // Threshold 1200 untuk ESP32 ADC (0-4095)
  if (airQuality > 1200 || t > 35.0) {
    digitalWrite(LED_RED, HIGH);
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(RELAY_FAN, HIGH); // Nyalakan kipas/exhaust
    Serial.println(">>> STATUS: POLUSI TINGGI / PANAS - Ventilasi Aktif!");
  } else {
    digitalWrite(LED_RED, LOW);
    digitalWrite(LED_GREEN, HIGH);
    digitalWrite(RELAY_FAN, LOW);  // Matikan kipas
    Serial.println(">>> STATUS: LINGKUNGAN AMAN");
  }

  delay(2000); 
}